# Nexios TV (Android TV)
WebView shell around `app/src/main/assets/tv.html` (edit that file to change the UI/channels).

Build the APK without installing anything:
1. Create a GitHub repo, upload this whole folder, push.
2. Open the Actions tab > "Build APK" > download the `NexiosTV-apk` artifact (app-debug.apk).
3. Put it on the stick (USB / `adb install app-debug.apk` / any file manager), allow "unknown sources", open "Nexios TV".

Or open the folder in Android Studio and press Run.

## Your own tv.html
Replace `app/src/main/assets/tv.html` with your edited page. `nexios-patch.js` (same folder) is injected automatically
by MainActivity: new Sky channels, logo backdrop, device dashboard and the old-WebView YouTube fallback.
For the browser/GitHub Pages version add `<script src="nexios-patch.js"></script>` just before `</body>`.
