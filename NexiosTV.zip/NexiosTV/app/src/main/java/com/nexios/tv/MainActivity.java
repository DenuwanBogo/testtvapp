package com.nexios.tv;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
  private static final String HOST = "appassets.androidplatform.net";
  private WebView web;
  private FrameLayout root;
  private View custom;
  private WebChromeClient chrome;
  private WebChromeClient.CustomViewCallback customCb;
  private AudioManager am;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    root = new FrameLayout(this);
    web = new WebView(this);
    root.addView(web, new FrameLayout.LayoutParams(-1, -1));
    setContentView(root);

    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    s.setSupportMultipleWindows(false);
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
    web.setBackgroundColor(0xFF000000);
    web.addJavascriptInterface(new Bridge(), "TVApp");

    web.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        return r.isForMainFrame() && !HOST.equals(r.getUrl().getHost());
      }
    });
    chrome = new WebChromeClient() {
      @Override public void onShowCustomView(View v, CustomViewCallback cb) {
        if (custom != null) { cb.onCustomViewHidden(); return; }
        custom = v; customCb = cb;
        root.addView(v, new FrameLayout.LayoutParams(-1, -1));
        web.setVisibility(View.GONE);
      }
      @Override public void onHideCustomView() {
        if (custom == null) return;
        root.removeView(custom); custom = null;
        if (customCb != null) customCb.onCustomViewHidden();
        web.setVisibility(View.VISIBLE); web.requestFocus();
      }
    };
    web.setWebChromeClient(chrome);
    web.setFocusable(true);
    web.loadUrl("https://" + HOST + "/assets/tv.html");
    web.requestFocus();
  }

  /** Volume + mute straight on the device, so it works for every stream and embed. */
  private class Bridge {
    @JavascriptInterface public void adjustVolume(int d) {
      try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0); } catch (Exception e) {}
    }
    @JavascriptInterface public int getVolume() {
      int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
      return max == 0 ? 0 : am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max;
    }
    @JavascriptInterface public void toggleMute() {
      try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0); } catch (Exception e) {}
    }
  }

  @Override public boolean dispatchKeyEvent(KeyEvent e) {
    int k = e.getKeyCode();
    if (k == KeyEvent.KEYCODE_BACK) {
      if (e.getAction() == KeyEvent.ACTION_UP) onBackPressed();
      return true;
    }
    // TV remote keys the WebView would not pass on: forward them to the page
    if (k == 82 || k == 165 || k == 166 || k == 167 || k == 172 || k == 256 || k == 257 || k == 87 || k == 88) {
      if (e.getAction() == KeyEvent.ACTION_DOWN)
        web.evaluateJavascript("window.tvKey&&window.tvKey(" + k + ")", null);
      return true;
    }
    return super.dispatchKeyEvent(e);
  }

  @Override public void onBackPressed() {
    if (custom != null) { chrome.onHideCustomView(); return; }
    web.evaluateJavascript("(window.tvBack?window.tvBack():false)", new ValueCallback<String>() {
      @Override public void onReceiveValue(String v) { if (!"true".equals(v)) finish(); }
    });
  }

  @Override public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
  }
  @Override protected void onPause() { super.onPause(); web.onPause(); }
  @Override protected void onResume() { super.onResume(); web.onResume(); }
  @Override protected void onDestroy() { super.onDestroy(); web.destroy(); }
}
