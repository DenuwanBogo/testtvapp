# Nexios TV (Android TV)
WebView shell around `app/src/main/assets/tv.html` (edit that file to change the UI/channels).

Build the APK without installing anything:
1. Create a GitHub repo, upload this whole folder, push.
2. Open the Actions tab > "Build APK" > download the `NexiosTV-apk` artifact (app-debug.apk).
3. Put it on the stick (USB / `adb install app-debug.apk` / any file manager), allow "unknown sources", open "Nexios TV".

Or open the folder in Android Studio and press Run.
